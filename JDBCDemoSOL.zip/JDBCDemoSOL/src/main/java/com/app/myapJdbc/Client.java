package com.app.myapJdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {

	public static void main(String[] args) {

ApplicationContext ctx = new AnnotationConfigApplicationContext(MyConfig.class);

       PersonService ps= (PersonService)ctx.getBean("personService");
       
       Person p= new Person();
       p.setPersonId(101);
       p.setFirstName("admin");
       p.setLastName("manager");
       p.setAge(22);
       ps.addPerson(p);
	}

}
