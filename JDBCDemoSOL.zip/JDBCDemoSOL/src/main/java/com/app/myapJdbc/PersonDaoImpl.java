package com.app.myapJdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Qualifier("personDao")
public class PersonDaoImpl implements PersonDao{
	
	 @Autowired
		JdbcTemplate jdbcTemplate;

	public void addPerson(Person person) {
		
		jdbcTemplate.update("insert into trn_person(person_id,first_name,last_name,age) values (?,?,?,?)",person.getPersonId(),person.getFirstName()
				,person.getLastName(),person.getAge());
		
		System.out.println("added");
	
		
		
	}
	

}
