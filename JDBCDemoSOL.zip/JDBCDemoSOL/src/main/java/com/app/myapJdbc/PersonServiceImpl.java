package com.app.myapJdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("personService")
public class PersonServiceImpl implements PersonService {
@Autowired
	private PersonDao personDao;
	
	public void addPerson(Person person) {
		
		personDao.addPerson(person);
	}

}
