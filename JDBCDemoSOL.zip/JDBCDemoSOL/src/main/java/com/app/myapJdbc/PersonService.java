package com.app.myapJdbc;

public interface PersonService {
	public void addPerson(Person person);

}
