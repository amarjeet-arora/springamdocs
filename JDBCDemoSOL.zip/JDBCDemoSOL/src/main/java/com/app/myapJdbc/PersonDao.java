package com.app.myapJdbc;

public interface PersonDao {
	
	public void addPerson(Person person);

}
