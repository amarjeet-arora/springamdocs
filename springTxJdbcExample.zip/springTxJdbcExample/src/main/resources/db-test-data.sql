insert into account(id, name, balance) values (1, "Joe", 2000);
insert into account(id, name, balance) values (2, "Jim", 1000);